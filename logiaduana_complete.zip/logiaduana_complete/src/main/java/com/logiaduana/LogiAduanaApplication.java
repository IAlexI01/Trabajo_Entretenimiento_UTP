package com.logiaduana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogiAduanaApplication {

    public static void main(String[] args) {
        SpringApplication.run(LogiAduanaApplication.class, args);
    }
}